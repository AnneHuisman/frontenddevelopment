var showArrow = document.querySelector('.turnOff');

var choice1 = document.querySelector('.choice1');
var choice2 = document.querySelector('.choice2');
var choice3 = document.querySelector('.choice3');
var choice4 = document.querySelector('.choice4');
var choice5 = document.querySelector('.choice5');
var choice6 = document.querySelector('.choice6');


choice1.addEventListener('click', select1, false);
choice2.addEventListener('click', select2, false);
choice3.addEventListener('click', select3, false);
choice4.addEventListener('click', select4, false);
choice5.addEventListener('click', select5, false);
choice6.addEventListener('click', select6, false);


function select1(){
	choice1.classList.add("btn-pink-half");
	
	choice2.classList.remove("btn-pink-half");
	choice3.classList.remove("btn-pink-half");
	choice4.classList.remove("btn-pink-half");
	choice5.classList.remove("btn-pink-half");
	choice6.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
}

function select2(){
	choice2.classList.add("btn-pink-half");
	
	choice1.classList.remove("btn-pink-half");
	choice3.classList.remove("btn-pink-half");
	choice4.classList.remove("btn-pink-half");
	choice5.classList.remove("btn-pink-half");
	choice6.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
	
}

function select3(){
	choice3.classList.add("btn-pink-half");

	choice1.classList.remove("btn-pink-half");
	choice2.classList.remove("btn-pink-half");
	choice4.classList.remove("btn-pink-half");
	choice5.classList.remove("btn-pink-half");
	choice6.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
}

function select4(){
	choice4.classList.add("btn-pink-half");

	choice1.classList.remove("btn-pink-half");
	choice2.classList.remove("btn-pink-half");
	choice3.classList.remove("btn-pink-half");
	choice5.classList.remove("btn-pink-half");
	choice6.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
}

function select5(){
	choice5.classList.add("btn-pink-half");

	choice1.classList.remove("btn-pink-half");
	choice2.classList.remove("btn-pink-half");
	choice3.classList.remove("btn-pink-half");
	choice4.classList.remove("btn-pink-half");
	choice6.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
}

function select6(){
	choice6.classList.add("btn-pink-half");

	choice1.classList.remove("btn-pink-half");
	choice2.classList.remove("btn-pink-half");
	choice3.classList.remove("btn-pink-half");
	choice4.classList.remove("btn-pink-half");
	choice5.classList.remove("btn-pink-half");

	showArrow.classList.remove("turnOff");
}
