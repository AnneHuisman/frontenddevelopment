var human = document.querySelector('.human');
var showArrow = document.querySelector('.turnOff');

var choice1 = document.querySelector('.choice1');
var choice2 = document.querySelector('.choice2');
var choice3 = document.querySelector('.choice3');
var choice4 = document.querySelector('.choice4');
var choice5 = document.querySelector('.choice5');
var choice6 = document.querySelector('.choice6');
var choice7 = document.querySelector('.choice7');
var choice8 = document.querySelector('.choice8');
var choice9 = document.querySelector('.choice9');
var choice10 = document.querySelector('.choice10');
var choice11 = document.querySelector('.choice11');
var choice12 = document.querySelector('.choice12');
var choice13 = document.querySelector('.choice13');

choice1.addEventListener('click', select1, false);
choice2.addEventListener('click', select2, false);
choice3.addEventListener('click', select3, false);
choice4.addEventListener('click', select4, false);
choice5.addEventListener('click', select5, false);
choice6.addEventListener('click', select6, false);
choice7.addEventListener('click', select7, false);
choice8.addEventListener('click', select8, false);
choice9.addEventListener('click', select9, false);
choice10.addEventListener('click', select10, false);
choice11.addEventListener('click', select11, false);
choice12.addEventListener('click', select12, false);
choice13.addEventListener('click', select13, false);

function select1(){
	choice1.classList.add("btn-pink-human");
	
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");
	
	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select1.png";
}

function select2(){
	choice2.classList.add("btn-pink-human");
	
	choice1.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select2.png";
}

function select3(){
	choice3.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select3.png";
}

function select4(){
	choice4.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select4.png";
}

function select5(){
	choice5.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select5.png";
}

function select6(){
	choice6.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select6.png";
}

function select7(){
	choice7.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select7.png";
}

function select8(){
	choice8.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select8.png";
}

function select9(){
	choice9.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select9.png";
}

function select10(){
	choice10.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select10.png";
}

function select11(){
	choice11.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select11.png";
}


function select12(){
	choice12.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice13.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select12.png";
}

function select13(){
	choice13.classList.add("btn-pink-human");

	choice1.classList.remove("btn-pink-human");
	choice2.classList.remove("btn-pink-human");
	choice3.classList.remove("btn-pink-human");
	choice4.classList.remove("btn-pink-human");
	choice5.classList.remove("btn-pink-human");
	choice6.classList.remove("btn-pink-human");
	choice7.classList.remove("btn-pink-human");
	choice8.classList.remove("btn-pink-human");
	choice9.classList.remove("btn-pink-human");
	choice10.classList.remove("btn-pink-human");
	choice11.classList.remove("btn-pink-human");
	choice12.classList.remove("btn-pink-human");

	showArrow.classList.remove("turnOff");
	human.src = "../assets/img/body/body-select13.png";
}
