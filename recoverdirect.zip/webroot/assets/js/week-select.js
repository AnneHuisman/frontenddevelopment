var showArrow = document.querySelector('.turnOff');

var choice1 = document.querySelector('.choice1');
var choice2 = document.querySelector('.choice2');
var choice3 = document.querySelector('.choice3');
var choice4 = document.querySelector('.choice4');


choice1.addEventListener('click', select1, false);
choice2.addEventListener('click', select2, false);
choice3.addEventListener('click', select3, false);
choice4.addEventListener('click', select4, false);


function select1(){
	choice1.classList.add("btn-pink-big");
	
	choice2.classList.remove("btn-pink-big");
	choice3.classList.remove("btn-pink-big");
	choice4.classList.remove("btn-pink-big");

	showArrow.classList.remove("turnOff");
}

function select2(){
	choice2.classList.add("btn-pink-big");
	
	choice1.classList.remove("btn-pink-big");
	choice3.classList.remove("btn-pink-big");
	choice4.classList.remove("btn-pink-big");

	showArrow.classList.remove("turnOff");
	
}

function select3(){
	choice3.classList.add("btn-pink-big");

	choice1.classList.remove("btn-pink-big");
	choice2.classList.remove("btn-pink-big");
	choice4.classList.remove("btn-pink-big");

	showArrow.classList.remove("turnOff");
}

function select4(){
	choice4.classList.add("btn-pink-big");

	choice1.classList.remove("btn-pink-big");
	choice2.classList.remove("btn-pink-big");
	choice3.classList.remove("btn-pink-big");

	showArrow.classList.remove("turnOff");
}
