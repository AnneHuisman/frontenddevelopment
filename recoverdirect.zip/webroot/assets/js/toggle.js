$(document).ready(function() {
  $(".info-today").hide();
  
  $(".header-today").click(function() {
    $(".info-today").slideToggle(600);
  });
});

// Source:http://www.littlewebhut.com/javascript/jquery_effects/
// Little Web Hut Javascript & jQuery Tutorials