$(document).ready(function() {
  $("#tickets").hide();
  
  $(".ticket-show").click(function() {
    $("#tickets").slideToggle(800);
  });
});

// Source:http://www.littlewebhut.com/javascript/jquery_effects/
// Little Web Hut Javascript & jQuery Tutorials